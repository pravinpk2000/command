package patterns.samples;

public interface Command {
	
	//String execute(HttpServletRequest request);
	
	String execute(String request);

}
